﻿from logging import getLogger, NOTSET, DEBUG, INFO, WARNING, ERROR, CRITICAL
from logs.logs import NtmLogsLoggerAdapter
from sys import exc_info

class _NTM_ (object):
    """ The ancestor class of all ntm classes
        to provide universal facilities such
        as logging.
    """

    adapter = None
    locale = { }

    def __init__(self, config = { 'locale': "en-US" }, extra = { }, *args, **kwargs):
        logger = getLogger(name = __name__)
        self.adapter = NtmLogsLoggerAdapter(logger, extra)
        self.locale = config['locale']
        return super(_NTM_, self).__init__(*args, **kwargs)

    def log(self, loglevel = INFO, logmsg = "", exc = None, *args, **kwargs):
        if exc is None:
            exc = exc_info()
        message = self.locale[logmsg] if logmsg in self.locale else logmsg
        self.adapter.log(loglevel, message, exc, *args, **kwargs)
