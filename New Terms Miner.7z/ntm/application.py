import ntm

ntm.main()
