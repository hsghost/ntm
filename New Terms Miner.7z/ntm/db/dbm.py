class dbm(object):
    """description of class"""


