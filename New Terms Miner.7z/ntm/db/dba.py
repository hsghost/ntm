﻿"""
Module ntm.db.dba

New Terms Miner Databases Access Module

@author: Aifeng Yun

    This module is impelented to facilitate the acess to the databases 
    required by the New Terms Miner.

"""

from .. import _NTM_
from .. import NOTSET, DEBUG, INFO, WARNING, ERROR, CRITICAL


class dba(_NTM_):
    """ The dba class provides database access facilities   """

    dbaConfig = { }

    def __init__(self, config):
        if config['dbs_type'] == "mysql":
            return 
        return super(dba, self).__init__(config)

    def useDB(self, **kwargs):
        pass

    def insertRecords(self, inserts, **kwargs):
        pass

    def deleteRecords(self, deletes, **kwargs):
        pass

    def updateRecords(self, updates, **kwargs):
        pass

    def queryRecords(self, query, **kwargs):
        pass

