__all__ = [ 'logs' ]

from .. import dictConfig
from .. import NOTSET, DEBUG, INFO, WARNING, ERROR, CRITICAL
from .. import jsonOp

#with jsonOp() as j:
#    with j.Read("config.json", "config.schema") as config:
#        dictConfig(config["logging"])
